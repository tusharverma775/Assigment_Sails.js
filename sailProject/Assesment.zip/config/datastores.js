module.exports.datastores = {
  default: {
    adapter: 'sails-mongo',
    url: 'mongodb+srv://tusharverma775:HYbfyzhJ4FzttEmO@cluster0.sfhrgxq.mongodb.net/Cluster0?retryWrites=true&w=majority&appName=Cluster0'
  },
};

