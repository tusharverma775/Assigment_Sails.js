module.exports.session = {
  secret: 'your-super-secret-key',
};
